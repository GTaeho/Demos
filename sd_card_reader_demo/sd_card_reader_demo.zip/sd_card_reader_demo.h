/*
 * ----------------------------------------------------------------------------
 *          Header file for fat32_demo.c (application entry point function)
 *                              written by Jungho Moon
 * ----------------------------------------------------------------------------
 */

#ifndef APP_MAIN_H
#define APP_MAIN_H

#ifdef  SYS_GLOBALS
#define SYS_EXT
#else
#define SYS_EXT extern
#endif

// user-defined types
#endif
